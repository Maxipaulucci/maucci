const express = require('express');
const router = express.Router();
const Reserva = require('../models/Reserva');
const Establecimiento = require('../models/Establecimiento');

// Función auxiliar para convertir duración (ej: "60 min") a minutos
const parseDuration = (duration) => {
  const match = duration.match(/(\d+)/);
  return match ? parseInt(match[1]) : 0;
};

// Función auxiliar para calcular horarios bloqueados
const calcularHorariosBloqueados = (horaInicio, duracionMinutos, intervalo = 30) => {
  const horariosBloqueados = [];
  const [hora, minutos] = horaInicio.split(':').map(Number);
  const inicioTotalMinutos = hora * 60 + minutos;
  const finTotalMinutos = inicioTotalMinutos + duracionMinutos;
  
  // Calcular cada intervalo que está ocupado
  let currentMinutos = inicioTotalMinutos;
  while (currentMinutos < finTotalMinutos) {
    const horas = Math.floor(currentMinutos / 60);
    const mins = currentMinutos % 60;
    const horaFormateada = `${String(horas).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
    horariosBloqueados.push(horaFormateada);
    currentMinutos += intervalo;
  }
  
  return horariosBloqueados;
};

// Función auxiliar para generar todos los horarios posibles según configuración
const generarHorariosDisponibles = (inicio, fin, intervalo) => {
  const horarios = [];
  const [horaInicio, minInicio] = inicio.split(':').map(Number);
  const [horaFin, minFin] = fin.split(':').map(Number);
  
  const inicioTotalMinutos = horaInicio * 60 + minInicio;
  const finTotalMinutos = horaFin * 60 + minFin;
  
  let currentMinutos = inicioTotalMinutos;
  while (currentMinutos <= finTotalMinutos) {
    const horas = Math.floor(currentMinutos / 60);
    const mins = currentMinutos % 60;
    const horaFormateada = `${String(horas).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
    horarios.push(horaFormateada);
    currentMinutos += intervalo;
  }
  
  return horarios;
};

// POST /api/reservas - Crear nueva reserva
router.post('/', async (req, res) => {
  try {
    const { establecimiento, fecha, hora, servicio, profesional, notas, usuarioEmail } = req.body;

    // Validaciones
    if (!establecimiento || !fecha || !hora || !servicio || !profesional || !usuarioEmail) {
      return res.status(400).json({
        success: false,
        message: 'Faltan campos requeridos (establecimiento, fecha, hora, servicio, profesional, usuarioEmail)'
      });
    }

    // Convertir duración a minutos
    const duracionMinutos = parseDuration(servicio.duration);
    if (duracionMinutos === 0) {
      return res.status(400).json({
        success: false,
        message: 'Duración del servicio inválida'
      });
    }

    // Obtener configuración del establecimiento para el intervalo
    const establecimientoConfig = await Establecimiento.findOne({ codigo: establecimiento });
    const intervalo = establecimientoConfig?.horarios?.intervalo || 30;
    
    // Verificar si hay conflictos de horario
    const fechaObj = new Date(fecha);
    
    // Buscar reservas existentes para el mismo establecimiento, profesional y fecha
    const fechaInicio = new Date(fechaObj);
    fechaInicio.setHours(0, 0, 0, 0);
    const fechaFin = new Date(fechaObj);
    fechaFin.setHours(23, 59, 59, 999);
    
    const reservasExistentes = await Reserva.find({
      establecimiento,
      fecha: {
        $gte: fechaInicio,
        $lt: fechaFin
      },
      'profesional.id': profesional.id
    });

    // Verificar conflictos
    const horariosBloqueados = calcularHorariosBloqueados(hora, duracionMinutos, intervalo);
    for (const reserva of reservasExistentes) {
      const horariosReserva = calcularHorariosBloqueados(reserva.hora, reserva.duracionMinutos, intervalo);
      const hayConflicto = horariosBloqueados.some(h => horariosReserva.includes(h));
      
      if (hayConflicto) {
        return res.status(400).json({
          success: false,
          message: 'El horario seleccionado no está disponible para este profesional'
        });
      }
    }

    // Crear nueva reserva
    const nuevaReserva = new Reserva({
      establecimiento,
      fecha: new Date(fecha),
      hora,
      servicio: {
        id: servicio.id,
        name: servicio.name,
        duration: servicio.duration,
        price: servicio.price
      },
      profesional: {
        id: profesional.id,
        name: profesional.name
      },
      duracionMinutos,
      notas: notas || '',
      usuarioEmail
    });

    await nuevaReserva.save();

    res.status(201).json({
      success: true,
      message: 'Reserva creada exitosamente',
      reserva: nuevaReserva
    });
  } catch (error) {
    console.error('Error al crear reserva:', error);
    res.status(500).json({
      success: false,
      message: 'Error al crear la reserva',
      error: error.message
    });
  }
});

// GET /api/reservas - Obtener reservas con filtros opcionales
router.get('/', async (req, res) => {
  try {
    const { establecimiento, fecha, profesionalId } = req.query;
    
    const query = {};
    
    // Establecimiento es requerido
    if (!establecimiento) {
      return res.status(400).json({
        success: false,
        message: 'El parámetro establecimiento es requerido'
      });
    }
    query.establecimiento = establecimiento;
    
    if (fecha) {
      const fechaObj = new Date(fecha);
      const inicioDia = new Date(fechaObj);
      inicioDia.setHours(0, 0, 0, 0);
      const finDia = new Date(fechaObj);
      finDia.setHours(23, 59, 59, 999);
      query.fecha = {
        $gte: inicioDia,
        $lt: finDia
      };
    }
    
    if (profesionalId) {
      query['profesional.id'] = parseInt(profesionalId);
    }
    
    const reservas = await Reserva.find(query).sort({ fecha: 1, hora: 1 });
    
    res.json({
      success: true,
      reservas
    });
  } catch (error) {
    console.error('Error al obtener reservas:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener las reservas',
      error: error.message
    });
  }
});

// GET /api/reservas/horarios-disponibles - Obtener horarios disponibles para una fecha y profesional
router.get('/horarios-disponibles', async (req, res) => {
  try {
    const { establecimiento, fecha, profesionalId, servicioId } = req.query;
    
    if (!establecimiento || !fecha || !profesionalId || !servicioId) {
      return res.status(400).json({
        success: false,
        message: 'Faltan parámetros requeridos: establecimiento, fecha, profesionalId, servicioId'
      });
    }

    // Obtener configuración del establecimiento
    const establecimientoConfig = await Establecimiento.findOne({ codigo: establecimiento });
    
    if (!establecimientoConfig || !establecimientoConfig.activo) {
      return res.status(404).json({
        success: false,
        message: 'Establecimiento no encontrado o inactivo'
      });
    }
    
    const { inicio, fin, intervalo } = establecimientoConfig.horarios;
    
    // Obtener todas las reservas del establecimiento, profesional y fecha
    const fechaObj = new Date(fecha);
    const inicioDia = new Date(fechaObj);
    inicioDia.setHours(0, 0, 0, 0);
    const finDia = new Date(fechaObj);
    finDia.setHours(23, 59, 59, 999);
    
    const reservas = await Reserva.find({
      establecimiento,
      fecha: {
        $gte: inicioDia,
        $lt: finDia
      },
      'profesional.id': parseInt(profesionalId)
    });

    // Calcular todos los horarios bloqueados
    const horariosBloqueados = new Set();
    reservas.forEach(reserva => {
      const horarios = calcularHorariosBloqueados(reserva.hora, reserva.duracionMinutos, intervalo);
      horarios.forEach(h => horariosBloqueados.add(h));
    });

    // Obtener duración del servicio
    const duracionServicio = req.query.duracionMinutos ? parseInt(req.query.duracionMinutos) : 30;
    
    // Generar todos los horarios posibles según configuración del establecimiento
    const todosHorarios = generarHorariosDisponibles(inicio, fin, intervalo);
    
    // Convertir hora de cierre a minutos para validación
    const [horaFinNum, minFinNum] = fin.split(':').map(Number);
    const finTotalMinutos = horaFinNum * 60 + minFinNum;
    
    // Filtrar horarios que no están bloqueados Y que tienen suficiente tiempo disponible
    const horariosDisponibles = todosHorarios.filter(hora => {
      if (horariosBloqueados.has(hora)) {
        return false;
      }
      
      // Verificar que hay suficiente tiempo desde este horario
      const [horaNum, minNum] = hora.split(':').map(Number);
      const inicioMinutos = horaNum * 60 + minNum;
      const finMinutos = inicioMinutos + duracionServicio;
      
      // Verificar que no se exceda el horario de cierre
      if (finMinutos > finTotalMinutos) {
        return false;
      }
      
      // Verificar que todos los intervalos necesarios estén disponibles
      let currentMinutos = inicioMinutos;
      while (currentMinutos < finMinutos) {
        const horas = Math.floor(currentMinutos / 60);
        const mins = currentMinutos % 60;
        const horaFormateada = `${String(horas).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
        if (horariosBloqueados.has(horaFormateada)) {
          return false;
        }
        currentMinutos += intervalo;
      }
      
      return true;
    });
    
    res.json({
      success: true,
      horariosDisponibles,
      horariosBloqueados: Array.from(horariosBloqueados)
    });
  } catch (error) {
    console.error('Error al obtener horarios disponibles:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener horarios disponibles',
      error: error.message
    });
  }
});

module.exports = router;

