const express = require('express');
const router = express.Router();
const Usuario = require('../models/Usuario');
const { enviarCodigoVerificacion } = require('../services/emailService');

// POST /api/auth/register - Registrar nuevo usuario
router.post('/register', async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log('📝 Intento de registro:', { email, passwordLength: password?.length });

    // Validar que se proporcionen email y contraseña
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email y contraseña son requeridos'
      });
    }

    // Verificar si el usuario ya existe
    const usuarioExistente = await Usuario.findOne({ email });
    if (usuarioExistente) {
      return res.status(400).json({
        success: false,
        message: 'Este email ya está registrado'
      });
    }

    // Crear nuevo usuario
    const nuevoUsuario = new Usuario({
      email,
      password // Se encriptará automáticamente en el pre-save hook
    });

    // Generar código de verificación
    const codigo = nuevoUsuario.generarCodigoVerificacion();
    console.log('✅ Código generado:', codigo);

    // Guardar usuario
    await nuevoUsuario.save();
    console.log('✅ Usuario guardado:', nuevoUsuario._id);

    // Enviar código por email
    console.log('📧 Enviando código de verificación...');
    const emailResult = await enviarCodigoVerificacion(email, codigo);
    console.log('📧 Resultado del envío:', emailResult);

    // Si falla el envío del email y NO es modo desarrollo, eliminar el usuario
    if (!emailResult.success && !emailResult.devMode) {
      await Usuario.findByIdAndDelete(nuevoUsuario._id);
      return res.status(500).json({
        success: false,
        message: 'Error al enviar el código de verificación. Por favor intenta nuevamente.'
      });
    }

    // Si es modo desarrollo, informar al usuario que revise la consola
    const mensaje = emailResult.devMode 
      ? 'Usuario registrado. Revisa la consola del servidor para ver el código de verificación.'
      : 'Usuario registrado. Por favor verifica tu email con el código enviado.';

    console.log('✅ Registro exitoso');
    res.status(201).json({
      success: true,
      message: mensaje,
      data: {
        email: nuevoUsuario.email,
        emailVerificado: nuevoUsuario.emailVerificado,
        devMode: emailResult.devMode || false
      }
    });
  } catch (error) {
    console.error('❌ Error en registro:', error);
    console.error('❌ Stack trace:', error.stack);
    
    // Manejar errores de validación de Mongoose
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(', ')
      });
    }
    
    // Manejar errores de duplicado (email ya existe)
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'Este email ya está registrado'
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Error al registrar usuario',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Error interno del servidor'
    });
  }
});

// POST /api/auth/verify-email - Verificar email con código
router.post('/verify-email', async (req, res) => {
  try {
    const { email, codigo } = req.body;

    if (!email || !codigo) {
      return res.status(400).json({
        success: false,
        message: 'Email y código son requeridos'
      });
    }

    // Buscar usuario
    const usuario = await Usuario.findOne({ email });
    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    // Verificar si el email ya está verificado
    if (usuario.emailVerificado) {
      return res.status(400).json({
        success: false,
        message: 'Este email ya está verificado'
      });
    }

    // Verificar código
    if (!usuario.codigoVerificacion) {
      return res.status(400).json({
        success: false,
        message: 'No hay código de verificación pendiente. Por favor solicita uno nuevo.'
      });
    }

    if (usuario.codigoVerificacion !== codigo) {
      return res.status(400).json({
        success: false,
        message: 'Código de verificación incorrecto'
      });
    }

    // Verificar si el código expiró
    if (new Date() > usuario.codigoVerificacionExpira) {
      return res.status(400).json({
        success: false,
        message: 'El código de verificación ha expirado. Por favor solicita uno nuevo.'
      });
    }

    // Marcar email como verificado y limpiar código
    usuario.emailVerificado = true;
    usuario.codigoVerificacion = null;
    usuario.codigoVerificacionExpira = null;
    await usuario.save();

    res.json({
      success: true,
      message: 'Email verificado correctamente'
    });
  } catch (error) {
    console.error('Error en verificación:', error);
    res.status(500).json({
      success: false,
      message: 'Error al verificar email',
      error: error.message
    });
  }
});

// POST /api/auth/login - Iniciar sesión
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email y contraseña son requeridos'
      });
    }

    // Buscar usuario
    const usuario = await Usuario.findOne({ email });
    if (!usuario) {
      return res.status(401).json({
        success: false,
        message: 'Email o contraseña incorrectos'
      });
    }

    // Verificar contraseña
    const passwordValida = await usuario.compararPassword(password);
    if (!passwordValida) {
      return res.status(401).json({
        success: false,
        message: 'Email o contraseña incorrectos'
      });
    }

    // Verificar si el email está verificado
    if (!usuario.emailVerificado) {
      return res.status(403).json({
        success: false,
        message: 'Por favor verifica tu email antes de iniciar sesión',
        requiereVerificacion: true
      });
    }

    res.json({
      success: true,
      message: 'Inicio de sesión exitoso',
      data: {
        email: usuario.email,
        emailVerificado: usuario.emailVerificado
      }
    });
  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({
      success: false,
      message: 'Error al iniciar sesión',
      error: error.message
    });
  }
});

// POST /api/auth/resend-code - Reenviar código de verificación
router.post('/resend-code', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email es requerido'
      });
    }

    const usuario = await Usuario.findOne({ email });
    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuario no encontrado'
      });
    }

    if (usuario.emailVerificado) {
      return res.status(400).json({
        success: false,
        message: 'Este email ya está verificado'
      });
    }

    // Generar nuevo código
    const codigo = usuario.generarCodigoVerificacion();
    await usuario.save();

    // Enviar código por email
    const emailResult = await enviarCodigoVerificacion(email, codigo);

    if (!emailResult.success && !emailResult.devMode) {
      return res.status(500).json({
        success: false,
        message: 'Error al enviar el código de verificación'
      });
    }

    const mensaje = emailResult.devMode 
      ? 'Código de verificación reenviado. Revisa la consola del servidor para ver el código.'
      : 'Código de verificación reenviado';

    res.json({
      success: true,
      message: mensaje
    });
  } catch (error) {
    console.error('Error reenviando código:', error);
    res.status(500).json({
      success: false,
      message: 'Error al reenviar código',
      error: error.message
    });
  }
});

module.exports = router;

