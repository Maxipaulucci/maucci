const express = require('express');
const router = express.Router();
const Establecimiento = require('../models/Establecimiento');

// GET /api/establecimientos - Obtener todos los establecimientos activos
router.get('/', async (req, res) => {
  try {
    const establecimientos = await Establecimiento.find({ activo: true }).select('-__v');
    res.json({
      success: true,
      establecimientos
    });
  } catch (error) {
    console.error('Error al obtener establecimientos:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener establecimientos',
      error: error.message
    });
  }
});

// GET /api/establecimientos/:codigo - Obtener un establecimiento por código
router.get('/:codigo', async (req, res) => {
  try {
    const { codigo } = req.params;
    const establecimiento = await Establecimiento.findOne({ 
      codigo: codigo.toLowerCase(),
      activo: true 
    }).select('-__v');
    
    if (!establecimiento) {
      return res.status(404).json({
        success: false,
        message: 'Establecimiento no encontrado'
      });
    }
    
    res.json({
      success: true,
      establecimiento
    });
  } catch (error) {
    console.error('Error al obtener establecimiento:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener establecimiento',
      error: error.message
    });
  }
});

// POST /api/establecimientos - Crear nuevo establecimiento (solo para administradores)
router.post('/', async (req, res) => {
  try {
    const { codigo, nombre, horarios, diasDisponibles } = req.body;
    
    if (!codigo || !nombre || !horarios) {
      return res.status(400).json({
        success: false,
        message: 'Faltan campos requeridos: codigo, nombre, horarios'
      });
    }
    
    // Verificar si ya existe
    const existe = await Establecimiento.findOne({ codigo: codigo.toLowerCase() });
    if (existe) {
      return res.status(400).json({
        success: false,
        message: 'Ya existe un establecimiento con ese código'
      });
    }
    
    const nuevoEstablecimiento = new Establecimiento({
      codigo: codigo.toLowerCase(),
      nombre,
      horarios: {
        inicio: horarios.inicio || '09:00',
        fin: horarios.fin || '20:00',
        intervalo: horarios.intervalo || 30
      },
      diasDisponibles: diasDisponibles || [2, 3, 4, 5, 6]
    });
    
    await nuevoEstablecimiento.save();
    
    res.status(201).json({
      success: true,
      message: 'Establecimiento creado exitosamente',
      establecimiento: nuevoEstablecimiento
    });
  } catch (error) {
    console.error('Error al crear establecimiento:', error);
    res.status(500).json({
      success: false,
      message: 'Error al crear establecimiento',
      error: error.message
    });
  }
});

module.exports = router;

