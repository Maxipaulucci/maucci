const mongoose = require('mongoose');

const reservaSchema = new mongoose.Schema({
  establecimiento: {
    type: String,
    required: true,
    index: true
  },
  fecha: {
    type: Date,
    required: true
  },
  hora: {
    type: String,
    required: true
  },
  servicio: {
    id: {
      type: Number,
      required: true
    },
    name: {
      type: String,
      required: true
    },
    duration: {
      type: String,
      required: true
    },
    price: {
      type: String,
      required: true
    }
  },
  profesional: {
    id: {
      type: Number,
      required: true
    },
    name: {
      type: String,
      required: true
    }
  },
  duracionMinutos: {
    type: Number,
    required: true
  },
  notas: {
    type: String,
    default: ''
  },
  usuarioEmail: {
    type: String,
    required: true
  },
  fechaCreacion: {
    type: Date,
    default: Date.now
  }
});

// Índice para búsquedas rápidas por establecimiento, fecha, hora y profesional
reservaSchema.index({ establecimiento: 1, fecha: 1, hora: 1, 'profesional.id': 1 });

const Reserva = mongoose.model('Reserva', reservaSchema);

module.exports = Reserva;

