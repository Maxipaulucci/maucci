const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const usuarioSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\S+@\S+\.\S+$/, 'Por favor ingresa un email válido']
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  emailVerificado: {
    type: Boolean,
    default: false
  },
  codigoVerificacion: {
    type: String,
    default: null
  },
  codigoVerificacionExpira: {
    type: Date,
    default: null
  },
  fechaCreacion: {
    type: Date,
    default: Date.now
  }
});

// Middleware para encriptar la contraseña antes de guardar
usuarioSchema.pre('save', async function() {
  // Solo encriptar si la contraseña fue modificada
  if (!this.isModified('password')) {
    return;
  }

  try {
    // Generar salt y encriptar contraseña
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
  } catch (error) {
    throw error;
  }
});

// Método para comparar contraseñas
usuarioSchema.methods.compararPassword = async function(password) {
  return await bcrypt.compare(password, this.password);
};

// Método para generar código de verificación
usuarioSchema.methods.generarCodigoVerificacion = function() {
  // Generar código de 6 dígitos
  const codigo = Math.floor(100000 + Math.random() * 900000).toString();
  this.codigoVerificacion = codigo;
  // El código expira en 15 minutos
  this.codigoVerificacionExpira = new Date(Date.now() + 15 * 60 * 1000);
  return codigo;
};

const Usuario = mongoose.model('Usuario', usuarioSchema);

module.exports = Usuario;

