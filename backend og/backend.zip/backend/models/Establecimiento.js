const mongoose = require('mongoose');

const establecimientoSchema = new mongoose.Schema({
  codigo: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  nombre: {
    type: String,
    required: true
  },
  horarios: {
    inicio: {
      type: String,
      required: true,
      default: '09:00'
    },
    fin: {
      type: String,
      required: true,
      default: '20:00'
    },
    intervalo: {
      type: Number,
      required: true,
      default: 30 // minutos entre turnos
    }
  },
  diasDisponibles: {
    type: [Number], // 0 = Domingo, 1 = Lunes, ..., 6 = Sábado
    default: [2, 3, 4, 5, 6] // Martes a Sábado por defecto
  },
  activo: {
    type: Boolean,
    default: true
  },
  fechaCreacion: {
    type: Date,
    default: Date.now
  }
});

// Índice para búsquedas rápidas por código
establecimientoSchema.index({ codigo: 1 });

const Establecimiento = mongoose.model('Establecimiento', establecimientoSchema);

module.exports = Establecimiento;

