/**
 * Script para inicializar establecimientos en la base de datos
 * Ejecutar con: node scripts/inicializarEstablecimientos.js
 */

const mongoose = require('mongoose');
const Establecimiento = require('../models/Establecimiento');
require('dotenv').config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/macci';

const establecimientosIniciales = [
  {
    codigo: 'barberia',
    nombre: 'Barbería Clásica',
    horarios: {
      inicio: '09:00',
      fin: '20:00',
      intervalo: 30 // minutos entre turnos
    },
    diasDisponibles: [2, 3, 4, 5, 6], // Martes a Sábado (0 = Domingo, 6 = Sábado)
    activo: true
  }
  // Agregar más establecimientos aquí según sea necesario
];

async function inicializarEstablecimientos() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Conectado a MongoDB');

    for (const establecimientoData of establecimientosIniciales) {
      const existe = await Establecimiento.findOne({ codigo: establecimientoData.codigo });
      
      if (existe) {
        console.log(`⚠️  El establecimiento "${establecimientoData.codigo}" ya existe. Actualizando...`);
        await Establecimiento.findOneAndUpdate(
          { codigo: establecimientoData.codigo },
          establecimientoData,
          { new: true }
        );
        console.log(`✅ Establecimiento "${establecimientoData.codigo}" actualizado`);
      } else {
        const nuevoEstablecimiento = new Establecimiento(establecimientoData);
        await nuevoEstablecimiento.save();
        console.log(`✅ Establecimiento "${establecimientoData.codigo}" creado`);
      }
    }

    console.log('\n✅ Inicialización completada');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error);
    process.exit(1);
  }
}

inicializarEstablecimientos();

