# Configuración del Backend

## Requisitos Previos

1. **MongoDB** debe estar corriendo en `localhost:27017`
2. La base de datos `macci` debe existir (se creará automáticamente si no existe)
3. La colección `usuario` se creará automáticamente al registrar el primer usuario

## Configuración de Variables de Entorno

1. Crea un archivo `.env` en la carpeta `backend/`:
   ```bash
   cd backend
   # En Windows PowerShell:
   Copy-Item .env.example .env
   # O crea el archivo manualmente
   ```

2. Edita el archivo `backend/.env` y configura las siguientes variables:

   ```env
   # MongoDB (ya está configurado por defecto)
   MONGODB_URI=mongodb://localhost:27017/macci

   # Puerto del servidor (opcional, por defecto 5000)
   PORT=5000

   # Configuración de Email
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_USER=tu-email@gmail.com
   EMAIL_PASS=tu-contraseña-de-aplicacion
   ```

## Configuración de Gmail para Envío de Emails

Para usar Gmail como servicio de email, necesitas crear una "Contraseña de aplicación":

1. Ve a tu cuenta de Google: https://myaccount.google.com/
2. Activa la verificación en 2 pasos si no la tienes activada
3. Ve a "Seguridad" > "Contraseñas de aplicaciones"
4. Genera una nueva contraseña de aplicación para "Correo"
5. Copia la contraseña generada y úsala en `EMAIL_PASS` en el archivo `.env`

**Nota:** Si usas otro proveedor de email (Outlook, Yahoo, etc.), ajusta `EMAIL_HOST` y `EMAIL_PORT` según corresponda.

## Iniciar el Servidor

**Nota:** El backend está en la carpeta `backend/`. Todos los comandos deben ejecutarse desde la raíz del proyecto o desde la carpeta `backend/`.

### Opción 1: Desde la raíz del proyecto
```bash
npm run server
```

### Opción 2: Desde la carpeta backend
```bash
cd backend
npm start
```

### Opción 3: Backend y frontend simultáneamente (requiere `concurrently`)
```bash
npm install -g concurrently
npm run dev
```

El servidor estará disponible en `http://localhost:5000`

**Importante:** Asegúrate de tener instaladas las dependencias del backend:
```bash
cd backend
npm install
```

## Endpoints Disponibles

### POST `/api/auth/register`
Registra un nuevo usuario y envía un código de verificación por email.

**Body:**
```json
{
  "email": "usuario@ejemplo.com",
  "password": "contraseña123"
}
```

### POST `/api/auth/verify-email`
Verifica el email del usuario con el código recibido.

**Body:**
```json
{
  "email": "usuario@ejemplo.com",
  "codigo": "123456"
}
```

### POST `/api/auth/login`
Inicia sesión con email y contraseña (requiere email verificado).

**Body:**
```json
{
  "email": "usuario@ejemplo.com",
  "password": "contraseña123"
}
```

### POST `/api/auth/resend-code`
Reenvía el código de verificación a un email.

**Body:**
```json
{
  "email": "usuario@ejemplo.com"
}
```

## Estructura de la Base de Datos

### Colección: `usuario`

```javascript
{
  email: String (único, requerido),
  password: String (encriptada con bcrypt, requerido),
  emailVerificado: Boolean (default: false),
  codigoVerificacion: String (6 dígitos),
  codigoVerificacionExpira: Date (expira en 15 minutos),
  fechaCreacion: Date
}
```

## Notas Importantes

- Las contraseñas se encriptan automáticamente antes de guardarse en la base de datos usando bcrypt
- Los códigos de verificación expiran después de 15 minutos
- Un usuario no puede iniciar sesión hasta que verifique su email
- El código de verificación es de 6 dígitos numéricos

