const nodemailer = require('nodemailer');

// Verificar si las credenciales de email están configuradas
const emailConfigurado = process.env.EMAIL_USER && process.env.EMAIL_PASS;

// Configuración del transporter de nodemailer (solo si hay credenciales)
let transporter = null;
if (emailConfigurado) {
  transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: process.env.EMAIL_PORT || 587,
    secure: false, // true para 465, false para otros puertos
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });
}

// Función para enviar código de verificación
const enviarCodigoVerificacion = async (email, codigo) => {
  // Si no hay credenciales configuradas, mostrar código en consola (modo desarrollo)
  if (!emailConfigurado) {
    console.log('\n📧 ============================================');
    console.log('📧 MODO DESARROLLO - Email no configurado');
    console.log('📧 ============================================');
    console.log(`📧 Email destino: ${email}`);
    console.log(`📧 Código de verificación: ${codigo}`);
    console.log('📧 ============================================\n');
    return { success: true, messageId: 'dev-mode', devMode: true };
  }

  try {
    const mailOptions = {
      from: `"Maxturnos" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Código de verificación - Maxturnos',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
            }
            .container {
              background-color: #f9fafb;
              border-radius: 8px;
              padding: 30px;
              border: 1px solid #e5e7eb;
            }
            .header {
              text-align: center;
              margin-bottom: 30px;
            }
            .logo {
              font-size: 24px;
              font-weight: bold;
              color: #3b82f6;
              margin-bottom: 10px;
            }
            .code-box {
              background-color: white;
              border: 2px solid #3b82f6;
              border-radius: 8px;
              padding: 20px;
              text-align: center;
              margin: 30px 0;
            }
            .code {
              font-size: 32px;
              font-weight: bold;
              color: #3b82f6;
              letter-spacing: 8px;
              font-family: 'Courier New', monospace;
            }
            .footer {
              margin-top: 30px;
              padding-top: 20px;
              border-top: 1px solid #e5e7eb;
              text-align: center;
              color: #6b7280;
              font-size: 14px;
            }
            .warning {
              background-color: #fef3c7;
              border-left: 4px solid #f59e0b;
              padding: 15px;
              margin: 20px 0;
              border-radius: 4px;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Maxturnos</div>
              <h1>Verifica tu correo electrónico</h1>
            </div>
            
            <p>Hola,</p>
            <p>Gracias por registrarte en Maxturnos. Para completar tu registro, por favor ingresa el siguiente código de verificación:</p>
            
            <div class="code-box">
              <div class="code">${codigo}</div>
            </div>
            
            <div class="warning">
              <strong>⚠️ Importante:</strong> Este código expirará en 15 minutos. Si no solicitaste este código, puedes ignorar este correo.
            </div>
            
            <p>Si tienes alguna pregunta, no dudes en contactarnos.</p>
            
            <div class="footer">
              <p>Saludos,<br>El equipo de Maxturnos</p>
              <p style="font-size: 12px; color: #9ca3af;">
                Este es un correo automático, por favor no respondas a este mensaje.
              </p>
            </div>
          </div>
        </body>
        </html>
      `
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Email enviado:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Error enviando email:', error);
    // En caso de error, mostrar código en consola como fallback
    console.log('\n📧 ============================================');
    console.log('📧 ERROR AL ENVIAR EMAIL - Código de verificación:');
    console.log('📧 ============================================');
    console.log(`📧 Email destino: ${email}`);
    console.log(`📧 Código de verificación: ${codigo}`);
    console.log('📧 ============================================\n');
    return { success: false, error: error.message };
  }
};

module.exports = {
  enviarCodigoVerificacion
};

